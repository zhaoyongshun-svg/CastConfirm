package com.example.castconfirm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;

import com.example.castconfirm.upnp.DmrServer;

import java.util.UUID;

/** 前台服务：DLNA 接收端常驻。退回桌面/息屏后依然可被搜到，来请求时弹确认。 */
public class CastService extends Service {

    public static final int NOTIFICATION_ID = 1001;
    public static final String CHANNEL_ID = "cast_service";

    private DmrServer dmrServer;
    private WifiManager.MulticastLock multicastLock;

    @Override
    public void onCreate() {
        super.onCreate();
        startInForeground();

        WifiManager wifi = (WifiManager) getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
        multicastLock = wifi.createMulticastLock("castconfirm");
        multicastLock.setReferenceCounted(true);
        multicastLock.acquire();

        SharedPreferences sp = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        String uuid = sp.getString("device_uuid", null);
        if (uuid == null) {
            uuid = UUID.randomUUID().toString();
            sp.edit().putString("device_uuid", uuid).apply();
        }
        String name = sp.getString(MainActivity.KEY_NAME, "客厅电视");

        dmrServer = new DmrServer(uuid, name);
        try {
            dmrServer.startServer();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startInForeground();
        return START_STICKY;
    }

    private void startInForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL_ID, "投屏服务", NotificationManager.IMPORTANCE_LOW));
        }
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE);
        Notification n = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setContentTitle("遥控确认投屏")
                .setContentText("接收端运行中，等待投屏请求")
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                ? ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC : 0;
        ServiceCompat.startForeground(this, NOTIFICATION_ID, n, type);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (dmrServer != null) dmrServer.stopServer();
        if (multicastLock != null && multicastLock.isHeld()) multicastLock.release();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
