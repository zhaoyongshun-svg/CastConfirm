package com.example.castconfirm.upnp;

import android.content.Intent;
import android.net.Uri;

import com.example.castconfirm.App;
import com.example.castconfirm.ConfirmGate;
import com.example.castconfirm.PlayerActivity;

import org.fourthline.cling.model.types.UnsignedIntegerFourBytes;
import org.fourthline.cling.support.avtransport.AbstractAVTransportService;
import org.fourthline.cling.support.avtransport.AVTransportException;
import org.fourthline.cling.support.model.DeviceCapabilities;
import org.fourthline.cling.support.model.MediaInfo;
import org.fourthline.cling.support.model.PlayMode;
import org.fourthline.cling.support.model.PositionInfo;
import org.fourthline.cling.support.model.RecordQualityMode;
import org.fourthline.cling.support.model.StorageMedium;
import org.fourthline.cling.support.model.TransportAction;
import org.fourthline.cling.support.model.TransportInfo;
import org.fourthline.cling.support.model.TransportSettings;
import org.fourthline.cling.support.model.TransportState;
import org.fourthline.cling.support.model.TransportStatus;

/**
 * 关键拦截点：SetAVTransportURI 只存 URI；
 * Play() 触发遥控确认，允许才真正拉起播放器，拒绝/超时抛 701 给发送端。
 * 签名严格对齐 cling 2.1.1 AbstractAVTransportService。
 */
public class MyAVTransportService extends AbstractAVTransportService {

    private volatile String currentUri;
    private volatile boolean playing;

    @Override
    public TransportInfo getTransportInfo(UnsignedIntegerFourBytes instanceId) throws AVTransportException {
        return new TransportInfo(
                playing ? TransportState.PLAYING : TransportState.STOPPED,
                TransportStatus.OK,
                "1");
    }

    @Override
    public PositionInfo getPositionInfo(UnsignedIntegerFourBytes instanceId) throws AVTransportException {
        return new PositionInfo(1, "00:00:00", "NOT_IMPLEMENTED",
                currentUri == null ? "" : currentUri,
                "NOT_IMPLEMENTED", "NOT_IMPLEMENTED", 0, 0);
    }

    @Override
    public MediaInfo getMediaInfo(UnsignedIntegerFourBytes instanceId) throws AVTransportException {
        return new MediaInfo(currentUri == null ? "" : currentUri, "",
                new UnsignedIntegerFourBytes(1), "00:00:00", StorageMedium.NETWORK);
    }

    @Override
    public DeviceCapabilities getDeviceCapabilities(UnsignedIntegerFourBytes instanceId)
            throws AVTransportException {
        return new DeviceCapabilities(
                new StorageMedium[]{StorageMedium.NETWORK},
                new StorageMedium[0],
                new RecordQualityMode[0]);
    }

    @Override
    public TransportSettings getTransportSettings(UnsignedIntegerFourBytes instanceId)
            throws AVTransportException {
        return new TransportSettings(PlayMode.NORMAL, RecordQualityMode.NOT_IMPLEMENTED);
    }

    @Override
    protected TransportAction[] getCurrentTransportActions(UnsignedIntegerFourBytes instanceId) {
        return new TransportAction[]{TransportAction.Play, TransportAction.Stop};
    }

    @Override
    public UnsignedIntegerFourBytes[] getCurrentInstanceIds() {
        return new UnsignedIntegerFourBytes[]{new UnsignedIntegerFourBytes(0)};
    }

    @Override
    public void setAVTransportURI(UnsignedIntegerFourBytes instanceId, String currentURI,
                                  String currentURIMetaData) throws AVTransportException {
        // 只记录，不播放。真正的闸门在 play()。
        currentUri = currentURI;
        playing = false;
    }

    @Override
    public void setNextAVTransportURI(UnsignedIntegerFourBytes instanceId, String nextURI,
                                      String nextURIMetaData) throws AVTransportException {
    }

    @Override
    public void play(UnsignedIntegerFourBytes instanceId, String speed) throws AVTransportException {
        if (currentUri == null) {
            throw new AVTransportException(718, "No media URI");
        }
        boolean allowed = ConfirmGate.request(currentUri);
        if (!allowed) {
            playing = false;
            throw new AVTransportException(701, "Rejected by user on TV");
        }
        Intent i = new Intent(App.get(), PlayerActivity.class)
                .setData(Uri.parse(currentUri))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        App.get().startActivity(i);
        playing = true;
    }

    @Override
    public void stop(UnsignedIntegerFourBytes instanceId) throws AVTransportException {
        playing = false;
        Intent i = new Intent(App.get(), PlayerActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(PlayerActivity.EXTRA_STOP, true);
        App.get().startActivity(i);
    }

    @Override
    public void pause(UnsignedIntegerFourBytes instanceId) throws AVTransportException {
        stop(instanceId);
    }

    @Override
    public void record(UnsignedIntegerFourBytes instanceId) throws AVTransportException {
        throw new AVTransportException(701, "Record not supported");
    }

    @Override
    public void seek(UnsignedIntegerFourBytes instanceId, String unit, String target)
            throws AVTransportException {
        // MVP 不支持拖动，PlayerActivity 遥控可拖
    }

    @Override
    public void next(UnsignedIntegerFourBytes instanceId) throws AVTransportException {
    }

    @Override
    public void previous(UnsignedIntegerFourBytes instanceId) throws AVTransportException {
    }

    @Override
    public void setPlayMode(UnsignedIntegerFourBytes instanceId, String newPlayMode)
            throws AVTransportException {
    }

    @Override
    public void setRecordQualityMode(UnsignedIntegerFourBytes instanceId, String newRecordQualityMode)
            throws AVTransportException {
    }
}
