package com.example.castconfirm.upnp;

import android.content.Intent;
import android.net.Uri;

import com.example.castconfirm.App;
import com.example.castconfirm.ConfirmGate;
import com.example.castconfirm.PlayerActivity;

import org.fourthline.cling.support.avtransport.AbstractAVTransportService;
import org.fourthline.cling.support.avtransport.AVTransportException;
import org.fourthline.cling.support.model.DeviceCapabilities;
import org.fourthline.cling.support.model.MediaInfo;
import org.fourthline.cling.support.model.PositionInfo;
import org.fourthline.cling.support.model.RecordQualityMode;
import org.fourthline.cling.support.model.StorageMedium;
import org.fourthline.cling.support.model.TransportAction;
import org.fourthline.cling.support.model.TransportInfo;
import org.fourthline.cling.support.model.TransportState;
import org.fourthline.cling.support.model.TransportStatus;
import org.fourthline.cling.support.model.WriteStatus;

/**
 * 关键拦截点：SetAVTransportURI 只存 URI；
 * Play() 触发遥控确认，允许才真正拉起播放器，拒绝/超时抛 701 给发送端。
 */
public class MyAVTransportService extends AbstractAVTransportService {

    private volatile String currentUri;
    private volatile boolean playing;

    @Override
    public TransportInfo getTransportInfo(int instanceId) {
        return new TransportInfo(
                playing ? TransportState.PLAYING : TransportState.STOPPED,
                TransportStatus.OK,
                "1");
    }

    @Override
    public PositionInfo getPositionInfo(int instanceId) {
        return new PositionInfo(1, "00:00:00", "NOT_IMPLEMENTED",
                currentUri == null ? "" : currentUri,
                "NOT_IMPLEMENTED", "NOT_IMPLEMENTED", 0, 0);
    }

    @Override
    public MediaInfo getMediaInfo(int instanceId) {
        return new MediaInfo(currentUri == null ? "" : currentUri, "",
                "", "", "NETWORK", "NONE", WriteStatus.NOT_IMPLEMENTED);
    }

    @Override
    public DeviceCapabilities getDeviceCapabilities(int instanceId) {
        return new DeviceCapabilities(
                new StorageMedium[]{StorageMedium.NETWORK},
                new StorageMedium[0],
                new RecordQualityMode[0]);
    }

    @Override
    public TransportAction[] getCurrentTransportActions(int instanceId) {
        return new TransportAction[]{TransportAction.PLAY, TransportAction.STOP};
    }

    @Override
    public void setAVTransportURI(int instanceId, String currentURI, String currentURIMetaData)
            throws AVTransportException {
        // 只记录，不播放。真正的闸门在 play()。
        currentUri = currentURI;
        playing = false;
    }

    @Override
    public void play(String speed) throws AVTransportException {
        if (currentUri == null) {
            throw new AVTransportException(718, "No media URI");
        }
        boolean allowed = ConfirmGate.request(currentUri);
        if (!allowed) {
            playing = false;
            throw new AVTransportException(701, "Rejected by user on TV");
        }
        Intent i = new Intent(App.get(), PlayerActivity.class)
                .setData(Uri.parse(currentUri))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        App.get().startActivity(i);
        playing = true;
    }

    @Override
    public void stop() {
        playing = false;
        Intent i = new Intent(App.get(), PlayerActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(PlayerActivity.EXTRA_STOP, true);
        App.get().startActivity(i);
    }

    @Override
    public void pause() {
        // 暂停交给 PlayerActivity 遥控处理，DLNA pause 这里直接停
        stop();
    }

    @Override
    public void seek(int instanceId, String unit, String target) {
        // MVP 不支持拖动，PlayerActivity 遥控可拖
    }

    @Override
    public void setNextAVTransportURI(int instanceId, String nextURI, String nextURIMetaData) {
    }

    @Override
    public void previous(int instanceId) {
    }

    @Override
    public void next(int instanceId) {
    }

    @Override
    public void setRecordQualityMode(int instanceId, String newRecordQualityMode)
            throws AVTransportException {
    }

    @Override
    public void setRepeatMode(int instanceId, String repeatMode) {
    }

    @Override
    public void setShuffleMode(int instanceId, String shuffleMode) {
    }
}
