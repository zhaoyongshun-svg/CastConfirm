package com.example.castconfirm;

import android.content.Intent;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * 所有协议适配器(DLNA/AirPlay/Cast)都必须经过这里。
 * request() 阻塞协议线程，弹确认页等遥控结果；允许才返回 true。
 */
public class ConfirmGate {

    private static final Object LOCK = new Object();
    private static final long TIMEOUT_SECONDS = 10;

    private static CountDownLatch latch;
    private static boolean allowed;
    private static String pendingUri;

    /** @return true=遥控允许；false=拒绝或超时 */
    public static boolean request(String uri) {
        synchronized (LOCK) {
            latch = new CountDownLatch(1);
            allowed = false;
            pendingUri = uri;
        }
        Intent i = new Intent(App.get(), ConfirmActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        App.get().startActivity(i);
        try {
            latch.await(TIMEOUT_SECONDS, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return allowed;
    }

    public static void respond(boolean ok) {
        synchronized (LOCK) {
            allowed = ok;
            if (latch != null) latch.countDown();
        }
    }

    public static String getPendingUri() {
        synchronized (LOCK) {
            return pendingUri;
        }
    }
}
