package com.example.castconfirm.upnp;

import android.content.Intent;
import android.net.Uri;

import com.example.castconfirm.App;
import com.example.castconfirm.ConfirmGate;
import com.example.castconfirm.PlayerActivity;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import fi.iki.elonen.NanoHTTPD;

/**
 * 极简 DLNA DMR（MediaRenderer）：
 *  - SSDP 应答 M-SEARCH + 周期 NOTIFY
 *  - HTTP: /root.xml 设备描述, /scpd.xml 服务描述, /ctrl SOAP 控制
 *  - Play 前必须过 ConfirmGate（电视遥控器确认）
 * 不依赖 cling/jetty。
 */
public class DmrServer extends NanoHTTPD {

    private static final String SSDP_ADDR = "239.255.255.250";
    private static final int SSDP_PORT = 1900;
    private static final String DEVICE_TYPE = "urn:schemas-upnp-org:device:MediaRenderer:1";
    private static final String SERVICE_TYPE = "urn:schemas-upnp-org:service:AVTransport:1";

    private final String uuid;
    private final String friendlyName;
    private volatile String currentUri;
    private volatile boolean playing;

    private Thread ssdpThread;
    private volatile boolean running;
    private MulticastSocket ssdpSocket;

    public DmrServer(String uuid, String friendlyName) {
        super(0); // 随机可用端口
        this.uuid = uuid;
        this.friendlyName = friendlyName;
    }

    public void startServer() throws IOException {
        start(SOCKET_READ_TIMEOUT, false);
        running = true;
        ssdpThread = new Thread(this::ssdpLoop, "ssdp-responder");
        ssdpThread.start();
        sendNotify("ssdp:alive");
    }

    public void stopServer() {
        running = false;
        try { sendNotify("ssdp:byebye"); } catch (Exception ignored) { }
        try { if (ssdpSocket != null) ssdpSocket.close(); } catch (Exception ignored) { }
        try { if (ssdpThread != null) ssdpThread.join(500); } catch (Exception ignored) { }
        stop();
    }

    // ---------------- SSDP ----------------

    private void ssdpLoop() {
        try {
            ssdpSocket = new MulticastSocket(SSDP_PORT);
            InetAddress group = InetAddress.getByName(SSDP_ADDR);
            ssdpSocket.joinGroup(group);
            byte[] buf = new byte[4096];
            while (running) {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                ssdpSocket.receive(p);
                String data = new String(p.getData(), 0, p.getLength());
                handleSearch(data, p);
            }
        } catch (Exception ignored) {
            // 1900 被占用等情况：仅靠周期 NOTIFY 宣告
        }
    }

    private void handleSearch(String data, DatagramPacket from) {
        if (!data.startsWith("M-SEARCH")) return;
        Matcher m = Pattern.compile("ST:(.*)\r\n", Pattern.CASE_INSENSITIVE).matcher(data);
        String st = m.find() ? m.group(1).trim() : "ssdp:all";
        try {
            if (st.contains("ssdp:all")) {
                reply(from, "upnp:rootdevice", "uuid:" + uuid + "::upnp:rootdevice");
                reply(from, DEVICE_TYPE, "uuid:" + uuid + "::" + DEVICE_TYPE);
                reply(from, SERVICE_TYPE, "uuid:" + uuid + "::" + SERVICE_TYPE);
            } else if (st.equals("upnp:rootdevice")) {
                reply(from, "upnp:rootdevice", "uuid:" + uuid + "::upnp:rootdevice");
            } else if (st.equals(DEVICE_TYPE)) {
                reply(from, DEVICE_TYPE, "uuid:" + uuid + "::" + DEVICE_TYPE);
            } else if (st.equals(SERVICE_TYPE)) {
                reply(from, SERVICE_TYPE, "uuid:" + uuid + "::" + SERVICE_TYPE);
            } else if (st.equalsIgnoreCase("uuid:" + uuid)) {
                reply(from, st, st);
            }
        } catch (Exception ignored) { }
    }

    private void reply(DatagramPacket from, String st, String usn) throws IOException {
        String msg = "HTTP/1.1 200 OK\r\n"
                + "CACHE-CONTROL: max-age=1800\r\n"
                + "EXT:\r\n"
                + "LOCATION: " + location() + "\r\n"
                + "SERVER: Android UPnP/1.0 CastConfirm/0.1\r\n"
                + "ST: " + st + "\r\n"
                + "USN: " + usn + "\r\n"
                + "BOOTID.UPNP.ORG: 1\r\n"
                + "CONFIGID.UPNP.ORG: 1\r\n\r\n";
        byte[] out = msg.getBytes();
        DatagramPacket r = new DatagramPacket(out, out.length, from.getAddress(), from.getPort());
        if (ssdpSocket != null) ssdpSocket.send(r);
    }

    private void sendNotify(String nts) throws IOException {
        MulticastSocket s = new MulticastSocket();
        InetAddress group = InetAddress.getByName(SSDP_ADDR);
        String[] sts = {"upnp:rootdevice", DEVICE_TYPE, SERVICE_TYPE};
        for (String st : sts) {
            String usn = "uuid:" + uuid + "::" + st;
            if (st.equals("upnp:rootdevice")) usn = "uuid:" + uuid + "::upnp:rootdevice";
            String msg = "NOTIFY * HTTP/1.1\r\n"
                    + "HOST: " + SSDP_ADDR + ":" + SSDP_PORT + "\r\n"
                    + "CACHE-CONTROL: max-age=1800\r\n"
                    + "LOCATION: " + location() + "\r\n"
                    + "NT: " + st + "\r\n"
                    + "NTS: " + nts + "\r\n"
                    + "SERVER: Android UPnP/1.0 CastConfirm/0.1\r\n"
                    + "USN: " + usn + "\r\n"
                    + "BOOTID.UPNP.ORG: 1\r\n"
                    + "CONFIGID.UPNP.ORG: 1\r\n\r\n";
            byte[] out = msg.getBytes();
            s.send(new DatagramPacket(out, out.length, group, SSDP_PORT));
        }
        s.close();
    }

    private String location() {
        return "http://" + hostIp() + ":" + getListeningPort() + "/root.xml";
    }

    private static String hostIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback() || ni.isPointToPoint()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!a.isLoopbackAddress() && a instanceof Inet4Address) {
                        return a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) { }
        return "127.0.0.1";
    }

    // ---------------- HTTP ----------------

    @Override
    public Response serve(IHTTPSession session) {
        String uri = session.getUri();
        if ("/root.xml".equals(uri)) return xml(deviceDescription());
        if ("/scpd.xml".equals(uri)) return xml(scpd());
        if (uri.startsWith("/ctrl")) {
            try {
                Map<String, String> body = new HashMap<>();
                session.parseBody(body);
                String actionHeader = session.getHeaders().get("soapaction");
                String action = actionName(actionHeader);
                return handleAction(action, body.get("postData"));
            } catch (Exception e) {
                return fault(606, "Internal error");
            }
        }
        return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "404");
    }

    private Response xml(String s) {
        return newFixedLengthResponse(Response.Status.OK, "text/xml; charset=utf-8", s);
    }

    private static String actionName(String header) {
        if (header == null) return "";
        int h = header.indexOf('#');
        return h >= 0 ? header.substring(h + 1, header.length() - 1) : "";
    }

    private static String extract(String xml, String tag) {
        if (xml == null) return "";
        Matcher m = Pattern.compile("<[a-zA-Z0-9]*:?\b" + tag + "\b[^>]*>(.*?)</[a-zA-Z0-9]*:?\b" + tag + "\b>",
                Pattern.DOTALL).matcher(xml);
        return m.find() ? m.group(1).trim() : "";
    }

    private Response handleAction(String action, String req) {
        switch (action) {
            case "SetAVTransportURI":
                currentUri = decode(extract(req, "CurrentURI"));
                playing = false;
                return ok(action);
            case "Play": {
                if (currentUri == null || currentUri.isEmpty()) return fault(718, "No media URI");
                boolean allowed = ConfirmGate.request(currentUri);
                if (!allowed) {
                    playing = false;
                    return fault(701, "Rejected by user on TV");
                }
                Intent i = new Intent(App.get(), PlayerActivity.class)
                        .setData(Uri.parse(currentUri))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                App.get().startActivity(i);
                playing = true;
                return ok(action);
            }
            case "Stop":
                playing = false;
                App.get().startActivity(new Intent(App.get(), PlayerActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        .putExtra(PlayerActivity.EXTRA_STOP, true));
                return ok(action);
            case "Pause":
                playing = false;
                return ok(action);
            case "GetTransportInfo": {
                String state = playing ? "PLAYING" : "STOPPED";
                return ok(action, "CurrentTransportState>" + state + "</CurrentTransportState"
                        + "><CurrentTransportStatus>OK</CurrentTransportStatus"
                        + "><CurrentSpeed>1</CurrentSpeed");
            }
            case "GetPositionInfo":
                return ok(action, "Track>1</Track"
                        + "><TrackDuration>00:00:00</TrackDuration"
                        + "><TrackMetaData></TrackMetaData"
                        + "><TrackURI>" + esc(currentUri) + "</TrackURI"
                        + "><RelTime>00:00:00</RelTime"
                        + "><AbsTime>00:00:00</AbsTime"
                        + "><RelCount>0</RelCount"
                        + "><AbsCount>0</AbsCount");
            case "GetMediaInfo":
                return ok(action, "NrTracks>1</NrTracks"
                        + "><MediaDuration>00:00:00</MediaDuration"
                        + "><CurrentURI>" + esc(currentUri) + "</CurrentURI"
                        + "><CurrentURIMetaData></CurrentURIMetaData"
                        + "><NextURI></NextURI"
                        + "><NextURIMetaData></NextURIMetaData"
                        + "><PlayMedium>NETWORK</PlayMedium"
                        + "><RecordMedium>NOT_IMPLEMENTED</RecordMedium"
                        + "><WriteStatus>NOT_IMPLEMENTED</WriteStatus");
            case "GetCurrentTransportActions":
                return ok(action, "Actions>Play,Stop,Pause,Seek</Actions");
            case "Seek":
            case "SetPlayMode":
            case "GetTransportSettings":
                return ok(action, "PlayMode>NORMAL</PlayMode".equals("") ? "" : playModeBlock(action));
            default:
                return fault(401, "Invalid action: " + action);
        }
    }

    private String playModeBlock(String action) {
        if (action.equals("GetTransportSettings")) {
            return "PlayMode>NORMAL</PlayMode><RecQualityMode>NOT_IMPLEMENTED</RecQualityMode";
        }
        return "";
    }

    private Response ok(String action) {
        return ok(action, "");
    }

    private Response ok(String action, String inner) {
        String body = "<u:" + action + "Response xmlns:u=\"" + SERVICE_TYPE + "\">"
                + (inner.isEmpty() ? "" : "<" + inner + ">")
                + "</u:" + action + "Response>";
        return xml(envelope(body));
    }

    private Response fault(int code, String desc) {
        String body = "<s:Fault><faultcode>s:Client</faultcode><faultstring>UPnPError</faultstring>"
                + "<detail><UPnPError xmlns=\"urn:schemas-upnp-org:control-1-0\">"
                + "<errorCode>" + code + "</errorCode>"
                + "<errorDescription>" + desc + "</errorDescription>"
                + "</UPnPError></detail></s:Fault>";
        Response r = xml(envelope(body));
        r.setStatus(Response.Status.INTERNAL_ERROR);
        return r;
    }

    private static String envelope(String innerBody) {
        return "<?xml version=\"1.0\"?>"
                + "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\""
                + " s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">"
                + "<s:Body>" + innerBody + "</s:Body></s:Envelope>";
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private static String decode(String s) {
        if (s == null) return "";
        return s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">");
    }

    // ---------------- 描述 XML ----------------

    private String deviceDescription() {
        return "<?xml version=\"1.0\"?>"
                + "<root xmlns=\"urn:schemas-upnp-org:device-1-0\">"
                + "<specVersion><major>1</major><minor>0</minor></specVersion>"
                + "<device>"
                + "<deviceType>" + DEVICE_TYPE + "</deviceType>"
                + "<friendlyName>" + esc(friendlyName) + "</friendlyName>"
                + "<manufacturer>CastConfirm</manufacturer>"
                + "<manufacturerURL>https://example.com</manufacturerURL>"
                + "<modelName>CastConfirm Renderer</modelName>"
                + "<modelDescription>Remote-confirm DLNA renderer</modelDescription>"
                + "<UDN>uuid:" + uuid + "</UDN>"
                + "<serviceList><service>"
                + "<serviceType>" + SERVICE_TYPE + "</serviceType>"
                + "<serviceId>urn:upnp-org:serviceId:AVTransport</serviceId>"
                + "<SCPDURL>/scpd.xml</SCPDURL>"
                + "<controlURL>/ctrl</controlURL>"
                + "<eventSubURL>/evt</eventSubURL>"
                + "</service></serviceList>"
                + "</device></root>";
    }

    private String scpd() {
        return "<?xml version=\"1.0\"?>"
                + "<scpd xmlns=\"urn:schemas-upnp-org:service-1-0\">"
                + "<specVersion><major>1</major><minor>0</minor></specVersion>"
                + "<actionList>"
                + act("SetAVTransportURI", in("InstanceID","A_ARG_TYPE_InstanceID"),
                        in("CurrentURI","A_ARG_TYPE_URI"), in("CurrentURIMetaData","A_ARG_TYPE_CurrentURIMetaData"))
                + act("Play", in("InstanceID","A_ARG_TYPE_InstanceID"), in("Speed","A_ARG_TYPE_Speed"))
                + act("Stop", in("InstanceID","A_ARG_TYPE_InstanceID"))
                + act("Pause", in("InstanceID","A_ARG_TYPE_InstanceID"))
                + act("Seek", in("InstanceID","A_ARG_TYPE_InstanceID"), in("Unit","A_ARG_TYPE_SeekMode"), in("Target","A_ARG_TYPE_SeekTarget"))
                + act("GetTransportInfo", in("InstanceID","A_ARG_TYPE_InstanceID"),
                        out("CurrentTransportState","TransportState"),
                        out("CurrentTransportStatus","TransportStatus"),
                        out("CurrentSpeed","A_ARG_TYPE_Speed"))
                + act("GetPositionInfo", in("InstanceID","A_ARG_TYPE_InstanceID"),
                        out("Track","A_ARG_TYPE_Track"), out("TrackDuration","A_ARG_TYPE_TrackDuration"),
                        out("TrackMetaData","A_ARG_TYPE_TrackMetaData"), out("TrackURI","A_ARG_TYPE_TrackURI"),
                        out("RelTime","A_ARG_TYPE_RelTime"), out("AbsTime","A_ARG_TYPE_AbsTime"),
                        out("RelCount","A_ARG_TYPE_RelCount"), out("AbsCount","A_ARG_TYPE_AbsCount"))
                + act("GetMediaInfo", in("InstanceID","A_ARG_TYPE_InstanceID"),
                        out("NrTracks","A_ARG_TYPE_NumberOfTracks"), out("MediaDuration","A_ARG_TYPE_TrackDuration"),
                        out("CurrentURI","A_ARG_TYPE_URI"), out("CurrentURIMetaData","A_ARG_TYPE_CurrentURIMetaData"),
                        out("NextURI","NextURI"), out("NextURIMetaData","NextURIMetaData"),
                        out("PlayMedium","A_ARG_TYPE_PlayMedium"), out("RecordMedium","A_ARG_TYPE_RecordMedium"),
                        out("WriteStatus","A_ARG_TYPE_WriteStatus"))
                + act("GetCurrentTransportActions", in("InstanceID","A_ARG_TYPE_InstanceID"),
                        out("Actions","A_ARG_TYPE_SeekTarget"))
                + act("GetTransportSettings", in("InstanceID","A_ARG_TYPE_InstanceID"),
                        out("PlayMode","CurrentPlayMode"), out("RecQualityMode","CurrentRecordQualityMode"))
                + act("SetPlayMode", in("InstanceID","A_ARG_TYPE_InstanceID"), in("NewPlayMode","CurrentPlayMode"))
                + "</actionList>"
                + "<serviceStateTable>"
                + sv("TransportState", "string", true) + sv("TransportStatus", "string", true)
                + sv("CurrentPlayMode", "string", false) + sv("CurrentRecordQualityMode", "string", false)
                + sv("A_ARG_TYPE_InstanceID", "ui4", false) + sv("A_ARG_TYPE_Speed", "string", false)
                + sv("A_ARG_TYPE_URI", "string", false) + sv("A_ARG_TYPE_CurrentURIMetaData", "string", false)
                + sv("A_ARG_TYPE_Track", "ui4", false) + sv("A_ARG_TYPE_TrackDuration", "string", false)
                + sv("A_ARG_TYPE_TrackMetaData", "string", false) + sv("A_ARG_TYPE_TrackURI", "string", false)
                + sv("A_ARG_TYPE_RelTime", "string", false) + sv("A_ARG_TYPE_AbsTime", "string", false)
                + sv("A_ARG_TYPE_RelCount", "i4", false) + sv("A_ARG_TYPE_AbsCount", "i4", false)
                + sv("A_ARG_TYPE_NumberOfTracks", "ui4", false) + sv("A_ARG_TYPE_PlayMedium", "string", false)
                + sv("A_ARG_TYPE_RecordMedium", "string", false) + sv("A_ARG_TYPE_WriteStatus", "string", false)
                + sv("A_ARG_TYPE_SeekMode", "string", false) + sv("A_ARG_TYPE_SeekTarget", "string", false)
                + sv("NextURI", "string", false) + sv("NextURIMetaData", "string", false)
                + "</serviceStateTable></scpd>";
    }

    private static String act(String name, String... args) {
        StringBuilder sb = new StringBuilder("<action><name>").append(name).append("</name><argumentList>");
        for (String a : args) sb.append(a);
        return sb.append("</argumentList></action>").toString();
    }

    private static String in(String name, String sv) {
        return "<argument><name>" + name + "</name><direction>in</direction>"
                + "<relatedStateVariable>" + sv + "</relatedStateVariable></argument>";
    }

    private static String out(String name, String sv) {
        return "<argument><name>" + name + "</name><direction>out</direction>"
                + "<relatedStateVariable>" + sv + "</relatedStateVariable></argument>";
    }

    private static String sv(String name, String type, boolean events) {
        return "<stateVariable sendEvents=\"" + (events ? "yes" : "no") + "\">"
                + "<name>" + name + "</name><dataType>" + type + "</dataType></stateVariable>";
    }
}
