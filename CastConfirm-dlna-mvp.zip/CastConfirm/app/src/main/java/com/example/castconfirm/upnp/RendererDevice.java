package com.example.castconfirm.upnp;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.castconfirm.MainActivity;

import org.fourthline.cling.binding.annotations.AnnotationLocalServiceBinder;
import org.fourthline.cling.model.DefaultServiceManager;
import org.fourthline.cling.model.meta.DeviceDetails;
import org.fourthline.cling.model.meta.DeviceIdentity;
import org.fourthline.cling.model.meta.LocalDevice;
import org.fourthline.cling.model.meta.LocalService;
import org.fourthline.cling.model.meta.ManufacturerDetails;
import org.fourthline.cling.model.meta.ModelDetails;
import org.fourthline.cling.model.types.DeviceType;
import org.fourthline.cling.model.types.UDADeviceType;
import org.fourthline.cling.model.types.UDN;

import java.util.UUID;

public class RendererDevice {

    public static LocalDevice create(Context ctx) throws Exception {
        SharedPreferences sp = ctx.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        String uuid = sp.getString("device_uuid", null);
        if (uuid == null) {
            uuid = UUID.randomUUID().toString();
            sp.edit().putString("device_uuid", uuid).apply();
        }
        String friendlyName = sp.getString(MainActivity.KEY_NAME, "客厅电视");

        AnnotationLocalServiceBinder binder = new AnnotationLocalServiceBinder();
        LocalService<MyAVTransportService> avService =
                binder.read(MyAVTransportService.class);
        avService.setManager(new DefaultServiceManager<>(avService, MyAVTransportService.class));

        DeviceType type = new UDADeviceType("MediaRenderer", 1);
        DeviceDetails details = new DeviceDetails(
                friendlyName,
                new ManufacturerDetails("CastConfirm"),
                new ModelDetails("CC1", "CastConfirm Renderer", "0.1"));

        return new LocalDevice(new DeviceIdentity(new UDN(uuid)), type, details,
                new LocalService[]{avService});
    }
}
