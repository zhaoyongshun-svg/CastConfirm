package com.example.castconfirm;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.IBinder;
import android.app.Activity;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.castconfirm.upnp.RendererDevice;

import org.fourthline.cling.android.AndroidUpnpService;
import org.fourthline.cling.android.AndroidUpnpServiceImpl;

public class MainActivity extends Activity {

    public static final String PREFS = "cast_confirm";
    public static final String KEY_NAME = "device_name";

    private AndroidUpnpService upnpService;
    private WifiManager.MulticastLock multicastLock;
    private boolean deviceRegistered = false;

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            upnpService = (AndroidUpnpService) service;
            if (!deviceRegistered) {
                try {
                    upnpService.getRegistry().addDevice(
                            RendererDevice.create(MainActivity.this));
                    deviceRegistered = true;
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                            "DLNA 注册失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            upnpService = null;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        EditText nameEdit = findViewById(R.id.nameEdit);
        nameEdit.setText(sp.getString(KEY_NAME, "客厅电视"));

        findViewById(R.id.saveBtn).setOnClickListener(v -> {
            String n = nameEdit.getText().toString().trim();
            if (TextUtils.isEmpty(n)) n = "客厅电视";
            sp.edit().putString(KEY_NAME, n).apply();
            Toast.makeText(this, "已保存，重启应用后生效", Toast.LENGTH_SHORT).show();
        });

        WifiManager wifi = (WifiManager) getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
        multicastLock = wifi.createMulticastLock("castconfirm");
        multicastLock.setReferenceCounted(true);
        multicastLock.acquire();

        bindService(new Intent(this, AndroidUpnpServiceImpl.class),
                connection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (upnpService != null) {
            try {
                upnpService.getRegistry().removeAllLocalDevices();
            } catch (Exception ignored) {
            }
        }
        unbindService(connection);
        if (multicastLock != null && multicastLock.isHeld()) {
            multicastLock.release();
        }
    }
}
