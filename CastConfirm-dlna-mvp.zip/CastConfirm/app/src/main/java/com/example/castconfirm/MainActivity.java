package com.example.castconfirm;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

public class MainActivity extends Activity {

    public static final String PREFS = "cast_confirm";
    public static final String KEY_NAME = "device_name";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        EditText nameEdit = findViewById(R.id.nameEdit);
        nameEdit.setText(sp.getString(KEY_NAME, "客厅电视"));

        findViewById(R.id.saveBtn).setOnClickListener(v -> {
            String n = nameEdit.getText().toString().trim();
            if (TextUtils.isEmpty(n)) n = "客厅电视";
            sp.edit().putString(KEY_NAME, n).apply();
            Toast.makeText(this, "已保存，重启接收端后生效", Toast.LENGTH_SHORT).show();
        });

        TextView status = findViewById(R.id.statusText);
        status.setText("接收端服务运行中：按Home退回桌面不影响，开机自动启动");

        // 启动常驻前台服务（重复调用是安全的）
        ContextCompat.startForegroundService(this, new Intent(this, CastService.class));
    }
}
