package com.example.castconfirm;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.widget.Button;
import android.widget.TextView;

public class ConfirmActivity extends Activity {

    private static final int TOTAL_SECONDS = 10;
    private int remaining = TOTAL_SECONDS;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean finished = false;
    private TextView countdownText;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (finished) return;
            remaining--;
            if (remaining <= 0) {
                finishWith(false);
                return;
            }
            countdownText.setText(remaining + " 秒后自动拒绝");
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm);

        countdownText = findViewById(R.id.countdownText);
        Button allowBtn = findViewById(R.id.allowBtn);
        Button rejectBtn = findViewById(R.id.rejectBtn);

        allowBtn.setOnClickListener(v -> finishWith(true));
        rejectBtn.setOnClickListener(v -> finishWith(false));

        // 焦点默认在“拒绝”上，防止误按 OK 直接放行
        rejectBtn.requestFocus();

        TextView body = findViewById(R.id.bodyText);
        body.setText(getString(R.string.confirm_body)
                + "\n" + safeUri(ConfirmGate.getPendingUri()));

        countdownText.setText(remaining + " 秒后自动拒绝");
        handler.postDelayed(tick, 1000);
    }

    private String safeUri(String uri) {
        if (uri == null) return "";
        // 只显示协议+主机，避免长 URL 泄露隐私路径
        try {
            java.net.URL u = new java.net.URL(uri);
            return u.getProtocol() + "://" + u.getHost();
        } catch (Exception e) {
            return "";
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finishWith(false);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onPause() {
        // 弹窗被系统弹窗等打断，一律视为拒绝
        super.onPause();
        finishWith(false);
    }

    private void finishWith(boolean ok) {
        if (finished) return;
        finished = true;
        handler.removeCallbacks(tick);
        ConfirmGate.respond(ok);
        finish();
    }
}
