# CastConfirm — 带遥控确认的 DLNA 视频投屏（Android TV MVP）

手机 DLNA 视频App 投屏到电视时，电视必须遥控器按 OK 确认后才播放；拒绝/10秒超时即失败。

## 构建
1. Android Studio 打开本目录（Gradle 8.x + JDK 17，无 wrapper，用本机 Gradle）。
2. Sync 时 cling/jetty 从 https://4thline.org/m2 拉取（需能访问外网；失败见下）。
3. 连上电视/盒子 adb install app-debug.apk，或 Run 到 Android TV。

## 使用
1. 打开 App，记住界面显示的设备名（默认“客厅电视”，可改，改后重进生效）。
2. 手机视频App 里选投屏/DLNA，选这台电视并播放。
3. 电视弹出确认页，按 OK 允许，返回键或 10 秒无操作则拒绝。
4. 播放中：OK 暂停/继续，返回键断开投屏。

## 范围与已知限制
- 仅视频 URL 投屏（HLS/MP4 等 ExoPlayer 支持格式）；相册图片未做。
- 每次投屏都需确认（信任设备/免确认在 ConfirmGate 里留了接口）。
- Cast / AirPlay 未包含：Cast 需在 Google Cast SDK 开发者后台注册 Web Receiver 并申请 app id；AirPlay 视频端需商用 SDK。两者接入时复用 ConfirmGate.request() 即可。
- cling 2.1.1 年代较久：若 IDE 提示 AbstractAVTransportService 方法签名不一致，按 Alt+Enter 自动补全 override 即可；jetty 8 在部分新机型上如启动失败，换用商用 UPnP 库替换 upnp/ 包即可，确认层不用动。
- 电视需允许安装未知来源应用；确认页为普通 Activity，系统级弹窗需要厂商签名权限。

## 命令行 / GitHub 编译

### 1. 先生成 Gradle Wrapper（必须做一次）
本工程未附带 wrapper。本地装好 JDK 17 + Gradle 8.x 后执行：

    gradle wrapper --gradle-version 8.7

会生成 `gradlew` / `gradlew.bat` / `gradle/wrapper/`。**这三个要提交到 GitHub**，否则 CI 和别人 clone 后无法构建。

### 2. 本地命令行构建

    ./gradlew assembleDebug
    # 产物：app/build/outputs/apk/debug/app-debug.apk

### 3. 提交到 GitHub
`.gitignore` 已配好，直接 `git add . && git commit && git push` 即可。
仓库根目录推上去后，`.github/workflows/android.yml` 会自动在
push / PR 时构建 APK，产物在 Actions 页面的 Artifacts 里下载。

### 4. cling 仓库在国内/CI 的网络问题
build.gradle 从 `https://4thline.org/m2` 拉 cling 和 jetty。
若 Actions 或本地访问失败，给 `settings.gradle` 的
`dependencyResolutionManagement.repositories` 里 4thline 之前
再加一行镜像兜底：

    maven { url 'https://mirrors.cloud.tencent.com/nexus/repository/maven-public/' }

（该镜像聚合了 central，但不含 4thline 的 jetty 转存；如镜像也不含，
把 app/build.gradle 里 jetty 相关依赖显式声明为
`org.eclipse.jetty:jetty-server:8.1.8.v20121106` 等三个构件。）

## Release 签名构建

### 1. 生成 keystore（本地执行一次，务必保管好，丢了无法覆盖安装升级）
    keytool -genkeypair -v \
        -keystore release.keystore \
        -alias castconfirm \
        -keyalg RSA -keysize 2048 -validity 10950

### 2. 本地构建
在 `local.properties` 加入（该文件已被 gitignore，不会上传）：

    RELEASE_STORE_FILE=release.keystore 的绝对路径
    RELEASE_STORE_PASSWORD=你的密码
    RELEASE_KEY_ALIAS=castconfirm
    RELEASE_KEY_PASSWORD=你的密码

然后 `./gradlew assembleRelease`。

### 3. GitHub Actions 自动出签名包
需要先在仓库 Settings → Secrets and variables → Actions 添加 4 个 Secret：

| Secret 名 | 值 |
|---|---|
| RELEASE_KEYSTORE_BASE64 | `base64 -w0 release.keystore` 的输出 |
| RELEASE_STORE_PASSWORD | keystore 密码 |
| RELEASE_KEY_ALIAS | castconfirm |
| RELEASE_KEY_PASSWORD | key 密码 |

配置好后，打一个 tag 推送即自动构建：

    git tag v0.1.0 && git push origin v0.1.0

或手动在 Actions 页面运行 "Build Signed Release APK"。
签名信息缺失时 release 会自动回退 debug 签名，构建不会失败。

## 纯手机操作：不开电脑也能编译（GitHub Actions）

适合只有手机的情况，全程浏览器完成：

1. 在 GitHub 网页新建仓库，例如 `CastConfirm`（公开）。
2. Add file → Upload files，把 `CastConfirm-dlna-mvp.zip` 直接传上去
   （workflow 会自动识别并解压，**不需要解压后逐个传文件**）。
3. Add file → Create new file，文件名填 `.github/workflows/android.yml`
   （带斜杠，网页编辑器会自动建目录），把本仓库 `.github/workflows/android.yml`
   的内容粘贴进去，Commit。
4. 打开仓库 Actions 标签页，手动运行 "Build APK"。
5. 完成后进入该次运行，Artifacts 里下载 `castconfirm-debug-apk`。
6. 把 APK 传到电视安装（U盘 / “Send Files to TV”类App / 局域网文件共享）。

release 签名包同理：先在 Settings → Secrets 配好 4 个签名 Secret，
然后打 tag 推送或手动运行 "Build Signed Release APK"。
